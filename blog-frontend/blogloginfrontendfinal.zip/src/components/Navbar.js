import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Navbar, Nav, Button } from 'react-bootstrap';
import axios from 'axios';

const NavigationBar = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await axios.get('http://localhost:5000/users/checkAuth', { withCredentials: true });
       console.log(response.data.isAuthenticated)
        setIsAuthenticated(response.data.isAuthenticated);
      } catch (error) {
        setIsAuthenticated(false);
      }
    };

    checkAuth();
  });

  const handleLogout = async () => {
    try {
      const response = await axios.get('http://localhost:5000/users/logout', { withCredentials: true });
      console.log(response.data); // Check response data to verify server response
      setIsAuthenticated(false); // Update state
      localStorage.removeItem('token'); // Optionally remove token if used
      navigate('/users/login'); // Redirect to login page
    } catch (error) {
      console.error('Error logging out:', error.response ? error.response.data : error.message);
    }
  };
  

  return (
    <Navbar bg="light" expand="lg">
      <Navbar.Brand as={Link} to="/">My Blog App</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="mr-auto">
          <Nav.Link as={Link} to="/">Home</Nav.Link>
          {isAuthenticated && <Nav.Link as={Link} to="/blogs">Blogs</Nav.Link>}
        </Nav>
        <Nav>
          {isAuthenticated ? (
            <Button variant="outline-danger" onClick={handleLogout}>Logout</Button>
          ) : (
            <>
              <Nav.Link as={Link} to="/users/login">Login</Nav.Link>
              <Nav.Link as={Link} to="/users/register">Register</Nav.Link>
            </>
          )}
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
};

export default NavigationBar;
