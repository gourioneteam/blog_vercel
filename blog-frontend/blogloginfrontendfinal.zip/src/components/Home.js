import React from 'react';
import { Container } from 'react-bootstrap';

const Home = () => (
  <Container>
    <h1>Welcome to the Blog App</h1>
  </Container>
);

export default Home;
