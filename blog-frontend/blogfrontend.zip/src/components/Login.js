import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/users/login', { username, password }, { withCredentials: true }); // Ensure withCredentials is true
      console.log('Response:', response); // Debugging line
      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
        navigate('/blogs');
      } else {
        console.error('Login failed, no token received');
      }
    } catch (error) {
      console.error('Error logging in', error.response ? error.response.data : error.message);
    }
  };

  return (
    <div>
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;

/*
React: The main library for building the user interface.
useState: A React hook used to manage the component's state.
axios: A library used for making HTTP requests.
useNavigate: A hook from react-router-dom used for navigation.
wo state variables, username and password, are initialized to empty strings. 
These will hold the values entered by the user in the input fields.
The useNavigate hook is used to get the navigate function, which allows redirection to different routes.
The handleSubmit function is an asynchronous function that will handle the form submission.
e.preventDefault(): Prevents the default form submission behavior, which would normally reload the page.
axios.post: Sends a POST request to the specified URL (http://localhost:5000/users/login).
{ username, password }: The payload sent to the server containing the username and password entered by the user.
{ withCredentials: true }: Ensures that cookies are sent along with the request for cross-origin requests. This is necessary for session-based authentication.

*/