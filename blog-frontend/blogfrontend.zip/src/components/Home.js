import React from 'react';

const Home = () => (
  <div>
    <h1>Welcome to the Blog App</h1>
  </div>
);

export default Home;
