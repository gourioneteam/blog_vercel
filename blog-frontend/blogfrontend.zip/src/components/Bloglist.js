import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function BlogList() {
  const [blogs, setBlogs] = useState([]); // Initialize with an empty array
  const [error, setError] = useState('');
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await axios.get('http://localhost:5000/blogs', { withCredentials: true });
        setBlogs(response.data.blogs); // Assuming response.data contains the blogs array
        setUser(response.data.user); // Assuming response.data contains the user object
      } catch (error) {
        setError('Error fetching blogs');
        console.error('Error fetching blogs:', error.response ? error.response.data : error.message);
      }
    };

    fetchBlogs();
  }, []);

  return (
    <div>
      <h1>Blogs</h1>
      <Link to="/blogs/new">Add New Blog</Link>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <ul>
        {blogs.map((blog) => (
          <li key={blog._id}>
            <h2>{blog.title}</h2>
            <p>{blog.content}</p>
            {user && blog.author._id === user.id && (
              <>
                <Link to={`/blogs/${blog._id}/edit`}>Edit</Link>
                <button onClick={async () => {
                  try {
                    await axios.delete(`http://localhost:5000/blogs/${blog._id}`, { withCredentials: true });
                    setBlogs(blogs.filter((b) => b._id !== blog._id));
                  } catch (error) {
                    console.error('Error deleting blog:', error.response ? error.response.data : error.message);
                  }
                }}>Delete</button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default BlogList;
