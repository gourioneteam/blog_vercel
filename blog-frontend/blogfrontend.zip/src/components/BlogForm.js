import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const BlogForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (id) {
      const fetchBlog = async () => {
        try {
          const response = await axios.get(`http://localhost:5000/blogs/${id}`, { withCredentials: true });
          setTitle(response.data.title);
          setContent(response.data.content);
          setLoading(false);
        } catch (error) {
          setError('Error fetching blog');
          console.error('Error fetching blog:', error);
        }
      };

      fetchBlog();
    } else {
      setLoading(false);
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); // Reset error state
    try {
      if (id) {
        const response = await axios.put(`http://localhost:5000/blogs/${id}`, { title, content }, { withCredentials: true });
        console.log('Update response:', response.data);
      } else {
        const response = await axios.post('http://localhost:5000/blogs', { title, content }, { withCredentials: true });
        console.log('Create response:', response.data);
      }
      navigate('/blogs');
    } catch (error) {
      console.error('Error saving blog:', error.response ? error.response.data : error.message);
      setError('Error saving blog');
    }
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div>
      <h1>{id ? 'Edit Blog' : 'New Blog'}</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <textarea
          placeholder="Content"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        ></textarea>
        <button type="submit">Save</button>
      </form>
    </div>
  );
};

export default BlogForm;
