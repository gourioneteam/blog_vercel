const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
  const token = req.session.token;
  if (!token) {
    req.flash('error', 'You must be logged in to view this page');
    return res.redirect('/login');
  }
  
  jwt.verify(token, 'your-secret-key', (err, decoded) => {
    if (err) {
      req.flash('error', 'Invalid token');
      return res.redirect('/login');
    }
    req.user = decoded;
    next();
  });
};

module.exports = auth;
