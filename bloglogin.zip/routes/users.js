const express = require('express');
const router = express.Router();
const User = require('../models/user');
const jwt = require('jsonwebtoken');

router.get('/register', (req, res) => {
  res.render('register');
});

router.post('/register', async (req, res) => {
  const { username, password } = req.body;
  try {
    const newUser = new User({ username, password });
    await newUser.save();
    console.log('User registered successfully');
    // req.flash('success', 'You have registered successfully');
    res.redirect('/');
  } catch (error) {
    console.error('Error registering user:', error);
    // req.flash('error', 'Username already exists');
    res.redirect('/register');
  }
});
router.get('/login', (req, res) => {
  res.render('login');
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username });
    if (!user || !(await user.comparePassword(password))) {
      req.flash('error', 'Invalid username or password');
      return res.redirect('/login');
    }
    const token = jwt.sign({ id: user._id }, 'your-secret-key', { expiresIn: '1h' });
    req.session.token = token;
    req.flash('success', 'You are logged in');
    res.redirect('/blogs');
  } catch (error) {
    req.flash('error', 'An error occurred');
    res.redirect('/login');
  }
});

router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
