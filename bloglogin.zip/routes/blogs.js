const express = require('express');
const router = express.Router();
const Blog = require('../models/blog');
const auth = require('../middlewares/auth');

router.get('/', auth, async (req, res) => {
  const blogs = await Blog.find().populate('author');
  res.render('blogs', { blogs, user: req.user });
});

router.get('/new', auth, (req, res) => {
  res.render('blog_form', { blog: {}, user: req.user });
});

router.post('/', auth, async (req, res) => {
  const { title, content } = req.body;
  try {
    const newBlog = new Blog({ title, content, author: req.user.id });
    await newBlog.save();
    req.flash('success', 'Blog created successfully');
    res.redirect('/blogs');
  } catch (error) {
    req.flash('error', 'An error occurred');
    res.redirect('/blogs/new');
  }
});

router.get('/:id/edit', auth, async (req, res) => {
  const blog = await Blog.findById(req.params.id);
  if (!blog || blog.author.toString() !== req.user.id) {
    req.flash('error', 'You are not authorized to edit this blog');
    return res.redirect('/blogs');
  }
  res.render('blog_form', { blog, user: req.user });
});

router.post('/:id', auth, async (req, res) => {
  const { title, content } = req.body;
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog || blog.author.toString() !== req.user.id) {
      req.flash('error', 'You are not authorized to edit this blog');
      return res.redirect('/blogs');
    }
    blog.title = title;
    blog.content = content;
    await blog.save();
    req.flash('success', 'Blog updated successfully');
    res.redirect('/blogs');
  } catch (error) {
    req.flash('error', 'An error occurred');
    res.redirect(`/blogs/${req.params.id}/edit`);
  }
});

router.post('/:id/delete', auth, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog || blog.author.toString() !== req.user.id) {
      req.flash('error', 'You are not authorized to delete this blog');
      return res.redirect('/blogs');
    }
    await blog.deleteOne();
    req.flash('success', 'Blog deleted successfully');
    res.redirect('/blogs');
  } catch (error) {
    req.flash('error', 'An error occurred');
    res.redirect('/blogs');
  }
});

module.exports = router;
