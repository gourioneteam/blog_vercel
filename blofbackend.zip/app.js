const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const flash = require('connect-flash');
const cors = require('cors');

const app = express();
app.use(cors({
  origin: 'http://localhost:3000', // Ensure there's no trailing slash
  credentials: true
}));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/blog-app', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); // Add this line to parse JSON request bodies
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
}));
app.use(flash());

// View engine
app.set('view engine', 'pug');

// Routes
const indexRoutes = require('./routes/index');
const userRoutes = require('./routes/users');
const blogRoutes = require('./routes/blogs');

app.use('/', indexRoutes);
app.use('/users', userRoutes);
app.use('/blogs', blogRoutes);


const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
