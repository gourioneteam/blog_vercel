// const express = require('express');
// const router = express.Router();
// const Blog = require('../models/blog');
// const auth = require('../middlewares/auth');

// router.get('/', auth, async (req, res) => {
//   const blogs = await Blog.find().populate('author');
//   res.render('blogs', { blogs, user: req.user });
// });

// router.get('/new', auth, (req, res) => {
//   res.render('blog_form', { blog: {}, user: req.user });
// });

// router.post('/', auth, async (req, res) => {
//   const { title, content } = req.body;
//   try {
//     const newBlog = new Blog({ title, content, author: req.user.id });
//     await newBlog.save();
//     req.flash('success', 'Blog created successfully');
//     res.redirect('/blogs');
//   } catch (error) {
//     req.flash('error', 'An error occurred');
//     res.redirect('/blogs/new');
//   }
// });

// router.get('/:id/edit', auth, async (req, res) => {
//   const blog = await Blog.findById(req.params.id);
//   if (!blog || blog.author.toString() !== req.user.id) {
//     req.flash('error', 'You are not authorized to edit this blog');
//     return res.redirect('/blogs');
//   }
//   res.render('blog_form', { blog, user: req.user });
// });

// router.post('/:id', auth, async (req, res) => {
//   const { title, content } = req.body;
//   try {
//     const blog = await Blog.findById(req.params.id);
//     if (!blog || blog.author.toString() !== req.user.id) {
//       req.flash('error', 'You are not authorized to edit this blog');
//       return res.redirect('/blogs');
//     }
//     blog.title = title;
//     blog.content = content;
//     await blog.save();
//     req.flash('success', 'Blog updated successfully');
//     res.redirect('/blogs');
//   } catch (error) {
//     req.flash('error', 'An error occurred');
//     res.redirect(`/blogs/${req.params.id}/edit`);
//   }
// });

// router.post('/:id/delete', auth, async (req, res) => {
//   try {
//     const blog = await Blog.findById(req.params.id);
//     if (!blog || blog.author.toString() !== req.user.id) {
//       req.flash('error', 'You are not authorized to delete this blog');
//       return res.redirect('/blogs');
//     }
//     await blog.deleteOne();
//     req.flash('success', 'Blog deleted successfully');
//     res.redirect('/blogs');
//   } catch (error) {
//     req.flash('error', 'An error occurred');
//     res.redirect('/blogs');
//   }
// });
const express = require('express');
const router = express.Router();
const Blog = require('../models/blog');
const auth = require('../middlewares/auth');

// Get all blogs
router.get('/', auth, async (req, res) => {
  try {
    const blogs = await Blog.find().populate('author');
    res.json({ blogs, user: req.user }); // Send blogs and user information
  } catch (error) {
    res.status(500).json({ message: 'Error fetching blogs', error: error.message });
  }
});
// Create a new blog
router.post('/', auth, async (req, res) => {
  const { title, content } = req.body;
  try {
    const newBlog = new Blog({ title, content, author: req.user.id });
    await newBlog.save();
    res.status(201).json({ message: 'Blog created successfully', blog: newBlog });
  } catch (error) {
    res.status(400).json({ message: 'An error occurred', error: error.message });
  }
});

// Get a single blog by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id).populate('author');
    if (!blog) {
      return res.status(404).json({ message: 'Blog not found' });
    }
    res.json(blog);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching blog', error: error.message });
  }
});

// Update a blog
router.put('/:id', auth, async (req, res) => {
  const { title, content } = req.body;
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog || blog.author.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Unauthorized to edit this blog' });
    }
    blog.title = title;
    blog.content = content;
    await blog.save();
    res.json({ message: 'Blog updated successfully', blog });
  } catch (error) {
    res.status(400).json({ message: 'An error occurred' });
  }
});

// Delete a blog
router.delete('/:id', auth, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog || blog.author.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Unauthorized to delete this blog' });
    }
    await blog.deleteOne();
    res.json({ message: 'Blog deleted successfully' });
  } catch (error) {
    res.status(400).json({ message: 'An error occurred', error: error.message });
  }
});
const axios = require('axios');

// Spotify API credentials
const clientId = '5d39ad0e6ada483a8a573d46ffa580c2';
const clientSecret = 'a40d09c6078149bb9cfa398d08b23a50';

// Function to get access token from Spotify
const getAccessToken = async () => {
  const response = await axios.post('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', {
    headers: {
      'Authorization': 'Basic ' + Buffer.from(clientId + ':' + clientSecret).toString('base64'),
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  });
  return response.data.access_token;
};

// Route to get track data from Spotify API
router.get('/track/:id', async (req, res) => {
  const trackId = req.params.id;
  try {
    const accessToken = await getAccessToken();
    const response = await axios.get(`https://api.spotify.com/v1/tracks/${trackId}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


module.exports = router;
